# Master Code: 

**Master Code:** [click here for code](Product_Development/Software/Code_Updates/Master_Code.c)

Instructions to compile and load code onto Mbed?

---

# Unit Test Code: 

**IR sensor unit test:** [click here](Product_Development/Software/Component_Unit_Test/IR_sensors_unit_code.c)

**Speaker unit test:** [click here](Product_Development/Software/Component_Unit_Test/speaker_unit_code.c)

**Ultrasonic unit test:** [click here](Product_Development/Software/Component_Unit_Test/ultrasonic_sensor_unit_code.c)

**Temperature and humidity unit test:** [click here](Product_Development/Software/Component_Unit_Test/temperature_and_humidity_unit_code.c)


> The code for the [RCCar07](Product_Development/Software/Component_Unit_Test/RCCar07_Steering_and_Velocity_Unit_Code.c) was given. The code included functions for steering and velocity. The RCCar07 code was analysed and functions for steering and velocity were implemented into the [Master code](Product_Development/Software/Code_Updates/Master_Code.c). 
