# Project Management Log
## Project Management Discussion
* This team has been working so hard from the beginning of the year having the goal of creating something wonderful by the end of the year. The team memebers are making use of their previous skills and the experience the have. the team is always trying to stay on the track and not to be left behind. This is done by keeping accomlishing the assigned tasks by deadlines, reflecting on any obstacles and having them overcome and keeping motivating and supporting each other.  

* The team is showing a good exmaple of being able to running the project efficiently and collaboratively. This is clear when the team has been able to decide what their project idea will be after having done enough research about it. All team members have been participating in giving their ideas and opinons about how to achieve that goal. A set of requirements for the project have been identifid and discussed. The team are keeping adding to and editing these rquirements in order to enhance them. This is because the team gain more experience and knowledge about this project day by day.

* Everyone attends the lab sessions meetings and any other arranged Stand-Up meetings during the week ([A link to one of the Stand-Ups meetings](https://cseejira.essex.ac.uk/browse/A293011-98)). In every scrum meeting, a scrum retrospective is being held at the beginning of each scrum meeting to reflect on the progress of the team during the last sprint. After that, The sprint is being marked as complete in order to start a new one. the team starts to define the set of issues to be done during the next sprint by adding them to the backlog, then these issues are being distributed equally to the team members and moved to the new sprint. All team members are working collaboratively to make sure everyone understand the set of tasks which have to be accomplished by the end of the next sprint.

* The team members are using the Jira software as the method of communication. However, due to the current situation of the pendamic, all meeting are restricted to be only virtual using zoom meetings. This is considered one of the obstacles the team are having during communication. The face to face meetings have an advantage over the virtual ones in some ways. The team are working hard to overcome these obstacle by exploiting the advantages of the virtual meetings in order to limit the disadvanteges of not being able to communicate in the real life.
---
### Project Reports

* Throught the whole project tasks have been assigned on Jira. Currently we have 3 sprints each sprint representing two weeks, attached below are images of the burndown charts for the 3 sprints we have done so far. The use of burndown charts allows us to complete work on time as the guideline is a representation of the prediction of when work will be completed.

<img src="MVP/images/BurnDown_Chart_Sprint_1.jpg" alt="Burndown Chart of Sprint 1" width="1827" height="603">
Figure.1. Burndown Chart of Sprint 1.

* In figure.1. it can be seen that the produced graph does not follow the guideline as close, this is most likely due to us getting familiar with the jira system and assigning task however all open stories were completed on time for the sprint to be closed.


<img src="MVP/images/BurnDown_Chart_Sprint_2.jpg" alt="Burndown Chart of Sprint 2" width="1827" height="603">
Figure.2. Burndown Chart of Sprint 2.

* In figure.2. the graph loosly follows the guideline however not fully this is most likley because some issues had to be put from the story to the backlog to be completed properly.

<img src="MVP/images/BurnDown_Chart_Sprint_3.jpg" alt="Burndown Chart of Sprint 3" width="1827" height="603">
Figure.3. Burndown Chart of Sprint 3.

* In figure.3. the graph is more close to the guideline, there are tasks being assinged with deadlines during the week and not all tasks have been set to finish on the end of the sprint. There are many issues in the backlog that are also being completed within the week.

---

## Product backlog

<img src="MVP/images/Backlog_03_12_20.jpg" alt="Backlog_03_12_20.jpg" width="1795" height="537">

* Figure.1. Screen shot of the Backlog in jira as of 03/12/20 

* These are the current issues in the backlog. The risks we have currently identified have been put here so we can moniter them throughtout the project.
