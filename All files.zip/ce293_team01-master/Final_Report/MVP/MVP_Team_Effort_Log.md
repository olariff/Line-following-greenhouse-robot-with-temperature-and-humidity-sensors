# Team Effort Log
## AHMAD JAGHASI
### Sprint 1 (week 3 and 4)
* This [link](https://cseejira.essex.ac.uk/browse/A293011-2) is for the first assigned story to Ahmad in week 3 which has 2 story points. This task was about familiarising with the coomand-line of git. This taks has accomplished done successefully in 4 hours of watching videos, researching and doing the tasks in [GitLab](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/2c3bc0e83c7855eaf3bf8670a6c0664e34451dc5/collaboration.txt).

* This [link](https://cseejira.essex.ac.uk/browse/A293011-16) is for one of the stories assigned to Ahmad in week 4 which has 2 story pionts. This taks was about familiarising with Mbed website by creaing an account and knowing how to create a program and compiling it.

* This [link](https://cseejira.essex.ac.uk/browse/A293011-27) is for one the stories assigned to Ahmad in week 4 which has 10 story points. The task was about doing research about Two essential protocols in serial communication, namely SPI and I2C and about PWM. Three documents have been uploaded to Gitlab as an evidence. [SPI](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/95618ed755517b200ce90401915c32f6b84f746a/Week_4_Documents/Ahmad%20Jaghasi/description_of_SPI.pdf), [I2C](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/95618ed755517b200ce90401915c32f6b84f746a/Week_4_Documents/Ahmad%20Jaghasi/description_of_I2C.pdf) and [PWM](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/95618ed755517b200ce90401915c32f6b84f746a/Week_4_Documents/Ahmad%20Jaghasi/description%20of%20PWM%20.pdf).

### Sprint 2 (Week 5 and 6)
* This [link](https://cseejira.essex.ac.uk/browse/A293011-35)  is for one of the stories assigned to Ahamd in week 5. It has 7 story points. It was about watching a tutorial video about EAGLE software.

* This [link](https://cseejira.essex.ac.uk/browse/A293011-49)  is for one of the stories assigned to Ahamd in week 5. It has 7 story points. It was about following some tutorials in the EAGLE software website.

* This [link](https://cseejira.essex.ac.uk/browse/A293011-62) is for the story which was accomplished by Ahmad in week 6. This story has 10 story points. It was about completeting a set of challenges which involve obseraving how some codes work. These codes were about SPI, I2C and PWM. Moreover, a parts list has been provided as well in the document which has been uploaded to [GitLab](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/95618ed755517b200ce90401915c32f6b84f746a/Week_6_Documents/Ahmad/Ahmad_Week_6_Challenges.pdf).

### Sprint 3 (Week 7 and 8)
* This [link](https://cseejira.essex.ac.uk/browse/A293011-68) is for one the issues in week 7 which has 6 story points. Ahmad has completed this task by compiling and testing three codes in mbed compiler and uploaded the .bin files to [GitLab](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/tree/master/Week_7_Challenges/Ahmad).

* This [story](https://cseejira.essex.ac.uk/browse/A293011-87) was assigned to Ahmad in week 8. It has 5 story points. This story was about creating the discussion section of the Project Management Log for the MVP. This is [link](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/commit/95618ed755517b200ce90401915c32f6b84f746a) to the work done by Ahmad.

* This [subtask](https://cseejira.essex.ac.uk/browse/A293011-90) was assigned to Ahmad in week 8. It has 5 story points. It is about contributing to creaing the fourth document of the MVP, [Team Effort Log](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/3ae1b51aca2d6cab85b3d8244ac21b70456e1bd6/MVP/MVP%20Team%20Effort%20Log.md).

* This [story](https://cseejira.essex.ac.uk/browse/A293011-104) is crating a [document](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/88c810387eb909652e5f6fbe08a7617e530348eb/MVP/team01_mvp.pdf) having all links to the markdown documents in GitLab

* This [story](https://cseejira.essex.ac.uk/browse/A293011-107) was about editing the two codes for control the speed, angle and direction of the car. It has 10 story points and the evidence has been uploaded to [The Team Repository](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/tree/master/Week_8_Challenges/Ahmad)

## ROBERT LEEDHAM

### Sprint 1 (week 3 and 4)


* [This story](https://cseejira.essex.ac.uk/browse/A293011-9) was left unassigned for any team member to contribute to during sprint 1. I researched similar projects currently in development and created a [reference document](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_3_Documents/areas%20of%20interest%20and%20examples.pdf) of possible examples to base our project on.

* [This story](https://cseejira.essex.ac.uk/browse/A293011-28) was set and completed during sprint 1 and was worth 10 story points. The task gave the opportunity to research [PWM](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Research/Week_Research/Week_4_Documents/Robert%20Leedham/Pulse%20Width%20Modulation%20(PWM).pdf) control, and the data transfer protocols [SPI](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Research/Week_Research/Week_4_Documents/Robert%20Leedham/Serial%20Peripheral%20Interface%20(SPI).pdf) and [I2C](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Research/Week_Research/Week_4_Documents/Robert%20Leedham/Inter-integrated%20Circuit%20(I2C).pdf) which are to be used in the project. 

* [This sub-task](https://cseejira.essex.ac.uk/browse/A293011-12) was assigned to myself during sprint 1. It involved setting up an mbed account and getting familiar with the mbed compiler and simulator.

### Sprint 2 (week 5 and 6)
* [This story](https://cseejira.essex.ac.uk/browse/A293011-60) was set during sprint 2 and carried over to sprint 3. It was not fully completed but a [short document](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Research/Week_Research/Week_6_Documents/Robert/PWM_challenge_1.pdf) comparing different ways of achieving PWM was produced.

* [This story](https://cseejira.essex.ac.uk/browse/A293011-46) was set and completed during sprint 2 and was worth 3 story points. It was succesfully compelted by installing the eagle PCB software.

* [This story](https://cseejira.essex.ac.uk/browse/A293011-44) was assigned during sprint 2 and was worth 7 story points. The task required reading tutorials on the eagle PCB software. 

### Sprint 3 (week 7 and 8)
* [This story](https://cseejira.essex.ac.uk/browse/A293011-83) was set during sprint 3 and was worth 5 story points. The task involved [highlighting potential risks to our project](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Risk%20Management/Potential_Project_Risks.pdf) and creating documents to be used in the [risk log](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/MVP/MVP%20Requirements%20and%20Risk%20Log.md) of the MVP.

* [This story](https://cseejira.essex.ac.uk/browse/A293011-106) was added during sprint 3 and assigned to myself. I created a [blank template](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Scrum%20Retrospectives/Scrum_Retrospective_Template.docx) file for future scrum retrospectives and uploaded records from scrums [1](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Scrum%20Retrospectives/Scrum_01_Retrospective.pdf) and [2](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Scrum%20Retrospectives/Scrum_02_Retrospective.pdf).

* [This story](https://cseejira.essex.ac.uk/browse/A293011-91)  worth 5 story points was assigned during sprint 3. It required the completion of the individual [team effort log](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/MVP/MVP%20Team%20Effort%20Log.md).

*  [This task](https://cseejira.essex.ac.uk/browse/A293011-69) was carried out during the weekly scrum meeting. It involved using the mbed compiler to create [.bin files of the example codes](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/tree/master/Week_7_Challenges/Robert)  of PWM, SPI, and I2C.

## SAGAR KANDEL
### Sprint 1 (week 3 and 4)
* [This jira story](https://cseejira.essex.ac.uk/browse/A293011-4) involved getting familiar with using the command-line for git. It involved editing, pushing, pulling and commiting [collaboration.txt](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_3_Documents/collaboration.txt) file using the command-line of git and GitLab online site. This was story was assigned in week 3 and worth 2 story points. The story took 3 hours to sucessfully complete in [GitLab](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/commit/1eea75205b8e32087cdcfba404abe6a73c57182d). 

* [This jira sub-taks]() involved creating an [mbed account](https://os.mbed.com/teams/CE261-2014-15/) and getting familiar with using mbed complier and simulator. The task was to send the username to the module supervisor so we could be added to the CE293 Embedded : 2020-21 teams directory. 

* [This jira story](https://cseejira.essex.ac.uk/browse/A293011-9) was not assigned to any particular team member in sprint 1. I rearched the potential areas our project could focuse on. In the [Inital Thoughts on Design PDF](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_3_Documents/Initial_thoughts_on_Design_.pdf) mindmap I branched some of the project suggestion to give an key-aspect of the project such as what application they could be implemented on and how they would work.

* [This jira story](https://cseejira.essex.ac.uk/browse/A293011-29) was to research and write a one-page description of [SPI](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_4_Documents/Sagar%20Kandel/Description_of_SPI.pdf) protocol, one-page description of [I2C](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_4_Documents/Sagar%20Kandel/Description_of_I2C.pdf) protocol and one-page description of [PWM](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_4_Documents/Sagar%20Kandel/Description_of_PWM.pdf) control. This task was assigned 10 story points and was to be completed in week 4.  

### Sprint 2 (week 5 and 6)
* [This jira story](https://cseejira.essex.ac.uk/browse/A293011-61) I rearched a project proposal for a pathfinder for a greenhouse for monitoring temperature and humidity. I complied a basic component list and researched on how the component would be utilised in the pathfinder bot. This proposal was taken foward by the group as a project to focuse on. I uploaded a document on [GitLab](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_6_Documents/Sagar%20Kandel/_sk17834__week6.pdf) containing the research.  

* [This jira story](https://cseejira.essex.ac.uk/browse/A293011-61) was to successfully download the software on a personal computer. The task was to get familiar with using the software. The objective was to successfully open a given file. The story was assined 3 story point and was to be compleated in week 5. 

* [This jira story](https://cseejira.essex.ac.uk/browse/A293011-61) involved reading and watching video tutorials on the eagle PCB software. This story was assigned during sprint 2 and was worth 7 story points. 

### Sprint 3 (week 7 and 8)
* [This jira story](https://cseejira.essex.ac.uk/browse/A293011-81) was assigned 7 story points and the task was to write a demonstration log on what our inital design thought was on the pathfinder for monitoring temperature and humidity. The evidance of this can be found on [GitLab](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/edit/master/MVP/MVP%20Team%20Effort%20Log.md). 

* [This jira story](https://cseejira.essex.ac.uk/browse/A293011-89) required completing individual [team effort log](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/MVP/MVP%20Team%20Effort%20Log.md). The story was assigned 5 story points.  

* [This jirs story](https://cseejira.essex.ac.uk/browse/A293011-70) was carried out in week 7 during the scrum meeting. It involved analysing the codes for PWM, SPI and I2C and, using the mbed compiler to create [.bin files](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_7_Challenges/Sagar%20Kandel/Team01.zip), which were sent to the module advisor to test out. We observed the testing on screen on Zoom meeting.

* [This jira story](https://cseejira.essex.ac.uk/browse/A293011-76) was to create a parts list for suitable components will be using to create the pathfinder. It involved analysing requirements to determin what we might need to compleate our design. This story is worth 5 story points and the pathfinder parts list can be found on [GitLab](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Project%20Order%20List/Team_01_Project_Order_Form.xls). 

## Hamad Al-Marri
### Sprint 1 (week 3 and 4)
* [This work](https://cseejira.essex.ac.uk/browse/A293011-7) was the first task of this year which assigned in week 3 and worth  2 story points. It was about getting familiar with command-line git. This task was done after watching the introduction video of GitLab  in moodle.

* [This story](https://cseejira.essex.ac.uk/browse/A293011-17) assigned to Hamad in week 4, which estimate of 2 story points. The task was about set up an account in Mbed platform and know-how to compile a program in Mbed software.

* [This story](https://cseejira.essex.ac.uk/browse/A293011-25) assigned to Hamad in week 4, which has 10 story points. The task was researching and writing a one-page description of three protocols [SPI](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_4_Documents/Hamad%20Al-Marri/Description_of_SPI.pdf), [I2C](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_4_Documents/Hamad%20Al-Marri/Description_of_I2C.pdf) and [PWM](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_4_Documents/Hamad%20Al-Marri/Description_of_PWM.pdf).

### Sprint 2 (week 5 and 6)
* [This story](https://cseejira.essex.ac.uk/browse/A293011-39)  was assigned during sprint 2 in week 5 and has 7 story points. the task was about watching video tutorial about Eagle PCD software.

* [This story](https://cseejira.essex.ac.uk/browse/A293011-51) was assigned in week 5 and worth 7 story points. It was about reading some tutorials to get familiarise with Eagle PCB software.

* [This story](https://cseejira.essex.ac.uk/browse/A293011-63) has been done successfully but not on time it was uploaded on GitLab in week 7.it was assigned in week 6 which estimate of 10 story points. This task was about doing several challenges that ask for using Mbed simulator. Some codes were given to know the concept how it works and understand it. The codes given was about SPI, I2C and PWM. Document written in [Gitlab](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_6_Documents/Hamad/Week_6_Challenges_Hamad.pdf) shows how these protocols work in Mbed.

### Sprint 3 (week 7 and 6)
* [This story](https://cseejira.essex.ac.uk/browse/A293011-71) was assigned in week 7, which has 6 story points. This task is related to what we did in Week 6 and it was asked to use Mbed compiler to compile and test codes given and upload the bin files to [Gitlab](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_6_Documents/Hamad/Week_6_Challenges_Hamad.pdf).

* [This story](https://cseejira.essex.ac.uk/browse/A293011-85) requires complete  the last section of MVP document individually  which is [team effort log](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/MVP/MVP%20Team%20Effort%20Log.md).

## Sheriff Oladunjoye
### Sprint 1 (week 3 and 4)
* This [link](https://cseejira.essex.ac.uk/projects/A293011/issues/A293011-1?filter=doneissues) displays the completed task on jira, that required team 1 to get familiar with editing, pushing and pulling a [file](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_3_Documents/collaboration.txt) from both the local command line and that online on gitlab. This task was worth 3 story points. 

* I was also required to create an mbed account in order to get familiar with how mbed and its compiler works. This was worth 2 [story](https://cseejira.essex.ac.uk/projects/A293011/issues/A293011-15?filter=doneissues) points.

* Another task completed during this sprint was the [research](https://cseejira.essex.ac.uk/projects/A293011/issues/A293011-33?filter=doneissues) and one page written description of [PMW](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_4_Documents/Sheriff/PULSE_WIDTH_MODULATION.pdf), [12C](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_4_Documents/Sheriff/I2C.pdf) and [SPI](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_4_Documents/Sheriff/SERIAL_PERIPHERAL_INTERFACE.pdf). I also revised my understanding of diodes, LEDs and npn transistors. This took me about 24 hours to complete.

### Sprint 2 (week 5 and 6)
* This [story](https://cseejira.essex.ac.uk/projects/A293011/issues/A293011-43?filter=doneissues) required for me to intall CadSoft Eagle PCB software onto my computer system. This was sucessfully carried out and was assigned 3 story points.

* This [story](https://cseejira.essex.ac.uk/projects/A293011/issues/A293011-42?filter=doneissues) required watching and studying the Eagle PCB tutorials and was assigned 7 story points.

### Sprint 3 (week 7 and 8) 
* This [story](https://cseejira.essex.ac.uk/projects/A293011/issues/A293011-89?filter=allopenissues) requires the individual effort log of each team member to be completed.

* This [task](https://cseejira.essex.ac.uk/projects/A293011/issues/A293011-74?filter=doneissues) was carried out during our regular meeting time and compiling and testing the codes on mbed compiler and uploading the [bin files](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/tree/master/Week_7_Challenges/Sheriff#) of these codes. This was assigned to 6 story points.



## HARSH PATEL

### Sprint 1 (week 3 and 4)


* [This story](https://cseejira.essex.ac.uk/browse/A293011-8) was about learning and getting used to the command-line for git. This involved commands to push, pull, editing and commiting files. This was worth 2 story points and it took me 4 hours to complete.

* [This story](https://cseejira.essex.ac.uk/browse/A293011-8) involved following the given instructions. The first part was to create a mbed account with the correct username. After the account had been created we familiarised ourselfs with the mbed simulator and compiler.

* [This story](https://cseejira.essex.ac.uk/browse/A293011-30) was worth 10 story points and the set task was to research and write a one-page description of [SPI](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_4_Documents/Harsh%20Patel/Serial_Peripheral_Interface.pdf), [PWM](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_4_Documents/Harsh%20Patel/Pulse_Width_Modulation.pdf) and [I2c](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_4_Documents/Harsh%20Patel/Inter-Integrated_Circuit.pdf) these documents have been uploaded to gitlab.


### Sprint 2 (week 5 and 6)


* [This story](https://cseejira.essex.ac.uk/browse/A293011-38) was worth 7 story points and was sub-tasked to each member of the team. The task involved watching a video that was a tutorial about the EAGLE software.

* [This story](https://cseejira.essex.ac.uk/browse/A293011-50) was worth 7 story points and was sub-tasked to each member of the team. The task involved following the given tutorials about the EAGLE software. This task took 3 hours to accomplish.

* [This story](https://cseejira.essex.ac.uk/browse/A293011-54) was worth 3 story points and was sub-tasked to each member of the team. This task was to install the CadSoft EAGLE PCB software on our own personal machine. This task too me 2 hours to accomplish.

* [This story](https://cseejira.essex.ac.uk/browse/A293011-59) was worth 10 story points. The task has multiple parts to it; Firstly the video about a breadboard had to be watched, this video explained how to use one. Then on the Mbed simulator the demos for PwmOut and PwmSpeaker were ran to understand in further detail how to code using PWM and to see it in action and a [short observation](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_6_Documents/Harsh/Week_6.pdf) was recorded on the given code, this process was also followed for LCD display and Temperature/Humidity demos and a [short observation](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/Week_6_Documents/Harsh/Week_6.pdf) was made. There was also a short discussion on the components and modules we would require for this project.



### Sprint 3 (week 7 and 8)


* [This story](https://cseejira.essex.ac.uk/browse/A293011-72) was worth 6 story points and was carried out during the weekly meeting, it involved using the mbed compiler to create [.bin](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/tree/master/Week_7_Challenges/Harsh%20Patel) files of PWM, SPI and I2C.

* [This story](https://cseejira.essex.ac.uk/browse/A293011-78) was worth 2 points and the burndown charts have to be incoprated into the [Project Management Log](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/MVP/MVP%20Project%20Management%20Log.md) .

* [This story](https://cseejira.essex.ac.uk/browse/A293011-93) worth 5 points was to update the [team effort log](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/MVP/MVP%20Team%20Effort%20Log.md) .



## Darrel Widjaja

### Sprint 1 (Week 3 & 4)

* [This story](https://cseejira.essex.ac.uk/browse/A293011-6) was to learn and familiarise with git commands by watching an instruction video and attempting a quiz. It was worth 2 story points and took 2 hours to complete.

* [This issue](https://cseejira.essex.ac.uk/projects/A293011/issues/A293011-15) was to create and mbed account and to familiarise with the mbed compiler and simulator.

* [This story](https://cseejira.essex.ac.uk/projects/A293011/issues/A293011-32) was to research and study about SPI, PWM, and I2C and write a one page description about each topic. It was also required to revise about LEDs and diodes and NPN transistors. These documents have been uploaded to [gitlab](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/tree/master/Week_4_Documents/Darrel).



### Sprint 2 (Week 5 & 6)

* [This sub-task](https://cseejira.essex.ac.uk/projects/A293011/issues/A293011-40) was to watch an instruction video about installing the EAGLE CAD software and familiarise with it.

* [This sub-task](https://cseejira.essex.ac.uk/projects/A293011/issues/A293011-52) was to read up on a tutorial and further understanding the EAGLE CAD software. It is worth 7 story points.

* [This story](https://cseejira.essex.ac.uk/projects/A293011/issues/A293011-65) worth 10 story points, was to complete several challenges on Mbed simulator to further understand PWM. PwnOut and PwmSpeaker were run to observe how the PWM affects the output.



### Sprint 3 (Week 7 & 8)

* [This story](https://cseejira.essex.ac.uk/projects/A293011/issues/A293011-73) worth 6 story points, involved creating bin files of PWM, I2C, and SPI codes using the Mbed compiler. The files are uploaded on [gitlab](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/tree/master/Week_7_Challenges/Darrel).

* [This story](https://cseejira.essex.ac.uk/projects/A293011/issues/A293011-82) was to update the [group MVP](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/MVP/MVP%20Requirements%20and%20Risk%20Log.md) with the project requirements, and updating the [team effort log](https://cseegit.essex.ac.uk/2020_ce293/ce293_team01/-/blob/master/MVP/MVP%20Team%20Effort%20Log.md).
