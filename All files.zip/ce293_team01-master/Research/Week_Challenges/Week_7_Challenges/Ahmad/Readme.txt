These are the three .bin files which have been compiled, downloaded and tested in the mbed board.
They correspond to the three challenges for week 7.

The first one is showing how PWM can be utilised to contorl the brightness of a LED.
The second one is showing how to set a communication between master and slave devices using SPI.
The third one is showing how to set a communication between master and slave devices using I2C.
